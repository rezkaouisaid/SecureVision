import pyshark

def extract_pcapng_to_txt(pcapng_file, output_file):
    try:
        # Lecture du fichier pcapng
        capture = pyshark.FileCapture(pcapng_file)

        # Préparer le fichier texte de sortie
        with open(output_file, 'w') as file:
            # Écrire l'en-tête
            file.write("Source\tDestination\tApplication\tDSCP\tTraffic\n")

            for packet in capture:
                try:
                    # Extraction des données du paquet
                    source = packet.ip.src if hasattr(packet, 'ip') else "N/A"
                    destination = packet.ip.dst if hasattr(packet, 'ip') else "N/A"
                    protocol = packet.highest_layer  # Application (e.g., TCP, HTTP)
                    dscp = packet.ip.dsfield_dscp if hasattr(packet.ip, 'dsfield_dscp') else "000000"
                    length = packet.length  # Taille totale du paquet en octets
                    
                    # Conversion de la taille en KB
                    traffic_size = f"{int(length) / 1024:.2f} KB"

                    # Écrire les informations dans le fichier texte
                    file.write(f"{source}\t{destination}\t{protocol}\t{dscp}\t{traffic_size}\n")
                except AttributeError:
                    # En cas d'erreur dans l'extraction des attributs
                    continue

        print(f"Conversion réussie. Les données ont été enregistrées dans : {output_file}")
    except Exception as e:
        print(f"Une erreur est survenue : {e}")

# Nom du fichier à convertir
pcapng_file = 'logs.pcapng'  # Nom du fichier .pcapng
output_file = 'output.txt'   # Nom du fichier texte généré

extract_pcapng_to_txt(pcapng_file, output_file)
