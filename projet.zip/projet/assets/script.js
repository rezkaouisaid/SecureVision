document.addEventListener('DOMContentLoaded', function () {
    const appCtx = document.getElementById('appChart').getContext('2d');
    const protocolCtx = document.getElementById('protocolChart').getContext('2d');
    const qosCtx = document.getElementById('qosChart').getContext('2d');
    const tableBody = document.querySelector('table tbody');

    // Fonction pour générer des couleurs dynamiques
    function generateColors(count) {
        const colors = [];
        for (let i = 0; i < count; i++) {
            const hue = (i * 360 / count) % 360; // Répartir uniformément sur la roue chromatique
            colors.push(`hsl(${hue}, 70%, 50%)`);
        }
        return colors;
    }

    // Charger les données depuis conversations.txt
    fetch('conversations.txt')
        .then(response => response.text())
        .then(data => {
            const rows = data.split('\n').slice(1); // Ignorer l'en-tête
            const protocolCounts = {};
            const qosTraffic = {};
            const appCounts = {};

            // Parcourir chaque ligne pour extraire les données
            rows.forEach(row => {
                if (row.trim()) {
                    const columns = row.split('\t');
                    const source = columns[0];
                    const protocol = columns[2];
                    const dscp = columns[3];
                    const traffic = parseFloat(columns[4].replace(' KB', ''));

                    // Compter les occurrences des applications (sources)
                    appCounts[source] = (appCounts[source] || 0) + 1;

                    // Compter les protocoles
                    protocolCounts[protocol] = (protocolCounts[protocol] || 0) + 1;

                    // Ajouter le trafic QoS (DSCP)
                    qosTraffic[dscp] = (qosTraffic[dscp] || 0) + traffic;

                    // Ajouter une ligne au tableau
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${columns[0]}</td>
                        <td>${columns[1]}</td>
                        <td>${columns[2]}</td>
                        <td>${columns[3]}</td>
                        <td>${columns[4]}</td>
                    `;
                    tableBody.appendChild(tr);
                }
            });

            // Mettre à jour le graphique des applications
            const appLabels = Object.keys(appCounts);
            const appData = Object.values(appCounts);
            const appColors = generateColors(appLabels.length);

            new Chart(appCtx, {
                type: 'pie',
                data: {
                    labels: appLabels,
                    datasets: [{
                        data: appData,
                        backgroundColor: appColors,
                    }]
                }
            });

            // Mettre à jour le graphique des protocoles
            const protocolLabels = Object.keys(protocolCounts);
            const protocolData = Object.values(protocolCounts);
            const protocolColors = generateColors(protocolLabels.length);

            new Chart(protocolCtx, {
                type: 'doughnut',
                data: {
                    labels: protocolLabels,
                    datasets: [{
                        data: protocolData,
                        backgroundColor: protocolColors,
                    }]
                }
            });

            // Mettre à jour le graphique QoS
            const qosLabels = Object.keys(qosTraffic);
            const qosData = Object.values(qosTraffic);
            const qosColors = generateColors(qosLabels.length);

            new Chart(qosCtx, {
                type: 'bar',
                data: {
                    labels: qosLabels,
                    datasets: [{
                        label: 'Traffic (KB)',
                        data: qosData,
                        backgroundColor: qosColors,
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: { beginAtZero: true },
                    },
                    plugins: {
                        legend: { display: false },
                        title: {
                            display: true,
                            text: 'QoS Traffic',
                        },
                    },
                },
            });
        })
        .catch(err => console.error('Erreur de chargement des données :', err));
});
